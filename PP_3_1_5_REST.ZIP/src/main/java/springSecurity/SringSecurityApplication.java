package springSecurity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SringSecurityApplication {

    public static void main(String[] args) {
        SpringApplication.run(SringSecurityApplication.class, args);
    }

}